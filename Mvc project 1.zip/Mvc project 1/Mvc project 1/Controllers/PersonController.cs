﻿using Microsoft.AspNetCore.Mvc;
using Mvc_project_1.Models.NewFolder3;

namespace Mvc_project_1.Controllers
{
    public class PersonController : Controller
    {
        private readonly DatabaseContext _ctx;
        public PersonController(DatabaseContext ctx) {
            _ctx = ctx; 
        }
        public IActionResult Index()
        {
            ViewBag.greeting = "Hello World";
            ViewData["greeting2"] = "I'm using ViewData";
            //ViewBag and ViewData can send data only from ControllerToView

            //TempData can send data from one controller method to another controller method 
            TempData["greeting3"] = "Its Tempdata message";
            return View();
        }

        public IActionResult AddPerson()
        {
            return View();
        }

        [HttpPost]
        public IActionResult AddPerson(Person person)
        {
            if(!ModelState.IsValid)
            {
                return View();
            }
            try
            {
                _ctx.Person.Add(person);
                _ctx.SaveChanges();
                TempData["msg"] = "Added successfully";
                return RedirectToAction("AddPerson");
            }
            catch (Exception ex)
            {
                TempData["msg"] = "Could not added";
                return View();
            }
        }

        public IActionResult DisplayPersons()
        {
            var persons = _ctx.Person.ToList();
            return View(persons);
        }

        
        public IActionResult EditPerson(int id)
        {
            var person = _ctx.Person.Find(id);
            return View(person);

        }
        [HttpPost]
        public IActionResult EditPerson(Person person)
        {
            if (!ModelState.IsValid)
            {
                return View();
            }
            try
            {
                _ctx.Person.Update(person);
                _ctx.SaveChanges();
                TempData["msg"] = "Update successfully";
                return RedirectToAction("DisplayPersons");
            }
            catch (Exception ex)
            {
                TempData["msg"] = "Could not updated";
                return View();
            }
        }
        public IActionResult DeletePerson(int id)
        {
            try
            {
                var person = _ctx.Person.Find(id);
                if (person != null)
                {
                    _ctx.Person.Remove(person);
                    _ctx.SaveChanges();
                }
            }
            catch (Exception ex)
            {
            }
            return RedirectToAction("DisplayPersons");
        }
    }
}
